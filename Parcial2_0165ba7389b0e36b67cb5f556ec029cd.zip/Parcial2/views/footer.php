<footer>
    <div class="lineone"></div>
    <div class="linetwo"></div>
</footer>

</body>
</html>