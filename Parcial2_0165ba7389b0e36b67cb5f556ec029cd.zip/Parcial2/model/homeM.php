<?php

class Home {

    public function showHome(){
        $homeDir = 'homeViews.php';
        return $homeDir;
    }
}