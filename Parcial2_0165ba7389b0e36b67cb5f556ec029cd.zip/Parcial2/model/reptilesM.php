<?php

class Reptil {

    public function showReptil(){
        $RDir = 'reptilesViews.php';
        return $RDir;
    }
}