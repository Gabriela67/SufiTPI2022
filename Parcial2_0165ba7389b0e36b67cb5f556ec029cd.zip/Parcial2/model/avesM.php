<?php

class Ave {

    public function showAves(){
        $aveDir = 'avesViews.php';
        return $aveDir;
    }
}