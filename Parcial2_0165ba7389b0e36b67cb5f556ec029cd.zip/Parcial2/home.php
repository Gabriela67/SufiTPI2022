<?php
require_once 'render/layout.php';
Layout::showHeader();
Layout::showHome();
Layout::showFooter();