<?php
require_once 'render/layout.php';
Layout::showHeader();
Layout::showReptiles();
Layout::showFooter();