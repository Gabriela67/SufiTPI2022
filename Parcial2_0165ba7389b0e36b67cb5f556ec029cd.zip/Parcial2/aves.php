<?php
require_once 'render/layout.php';
Layout::showHeader();
Layout::showAves();
Layout::showFooter();