<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    use HasFactory;

    public static function database(){
        $database = file_get_contents('../database.json');
        return $database;
    }

    public static function getCustomers(){
        $data = json_decode( Customer::database(), true);
        return $data;
    }

    public static function getOneUser($id){
        $data = json_decode( Customer::database(), true);
        return $data[$id];
    }

    public static function getUserFriends($id){
        $data = json_decode( Customer::database(), true);
        return $data[$id]['friends'];
    }
    
    public static function createUser($Users,$newUser){
        array_push($Users,$newUser);
        $data = json_encode($Users);
        file_put_contents('../database.json',$data);
    }

}
