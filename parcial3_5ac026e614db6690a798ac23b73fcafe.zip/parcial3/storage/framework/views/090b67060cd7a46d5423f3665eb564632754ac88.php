<?php $__env->startSection('title','users'); ?>
<?php $__env->startSection('main'); ?>
<table class="default">
<tr>
    <td>id</td>
    <td>Nombre</td>
    <td>edad</td>
    <td>genero</td>
    <td>email</td>
    <td>telefono</td>
    <td>direccion</td>
  </tr>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
  
    <?php $__currentLoopData = $key; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e(var_dump($v)); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mainTemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/danys/Desktop/TPI-2022/Parcial3/parcial3/resources/views/user.blade.php ENDPATH**/ ?>