<?php

use App\Http\Controllers\CustomerController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::controller(CustomerController::class)->group(function (){
    Route::get('/customers', 'index')->name('index.customers');
    Route::get('/customers/nuevo' , 'createUser')->name('create.user');
    Route::get('/customers/{id}', 'User')->name('user.one');
    Route::get('/customers/{id}/friends' , 'UserFriends')->name('user.friends');
    Route::post('/customers' , 'store')->name('user.store');
});
