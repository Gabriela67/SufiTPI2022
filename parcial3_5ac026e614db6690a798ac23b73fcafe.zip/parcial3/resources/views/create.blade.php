<form action="{{route('user.store')}}" method="post">
@csrf
<label for="id">Id</label>
<input type="number" name="id", id="id">
<label for="edad">Edad</label>
<input type="number" name="edad", id="edad">
<label for="nombre">nombre</label>
<input type="text" name="nombre", id="nombre">
<label for="genero">genero</label>
<input type="text" name="genero", id="genero">
<label for="email">email</label>
<input type="email" name="email", id="email">
<label for="telefono">telefono</label>
<input type="number" name="telefono", id="telefono">
<label for="direccion">direccion</label>
<input type="text" name="direccion", id="direccion">

<button type="submit">Guardar</button>
</form>