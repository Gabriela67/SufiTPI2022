@extends('mainTemplate')
@section('title','users')
@section('main')
<table class="default">
<tr>
    <td>id</td>
    <td>Nombre</td>
    <td>edad</td>
    <td>genero</td>
    <td>email</td>
    <td>telefono</td>
    <td>direccion</td>
  </tr>
    @foreach ($data as $key)
    
  
    @foreach ($key as $v)
        {{var_dump($v)}}
    @endforeach

    @endforeach
</table>
@stop